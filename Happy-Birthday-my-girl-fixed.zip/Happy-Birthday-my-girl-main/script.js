const PASSWORD="2210";
window.onload=()=>{setTimeout(()=>{loader.style.display="none";passwordPage.style.display="flex";},1200);}
function checkPass(){if(pass.value===PASSWORD){passwordPage.style.display="none";main.style.display="block";}else wrong.innerText="Wrong Password";}
startBtn.onclick=()=>{document.getElementById("love-letter").scrollIntoView({behavior:"smooth"});}
nextBtn.onclick=()=>{document.getElementById("cakeSection").scrollIntoView({behavior:"smooth"});}
function cutCake(){document.querySelector(".cake").textContent="🍰";cakeText.textContent="🎉 Happy Birthday Riya ❤️";}